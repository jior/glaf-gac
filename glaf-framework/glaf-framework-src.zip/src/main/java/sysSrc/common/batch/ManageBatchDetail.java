package sysSrc.common.batch;

public class ManageBatchDetail {
	private String batName;
	private String startDate;
	private String interval;
	private String what;
	private String isUse;
	private String status;
	
	
	public String getBatName() {
		return batName;
	}
	public void setBatName(String batName) {
		this.batName = batName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getInterval() {
		return interval;
	}
	public void setInterval(String interval) {
		this.interval = interval;
	}
	public String getWhat() {
		return what;
	}
	public void setWhat(String what) {
		this.what = what;
	}
	public String getIsUse() {
		return isUse;
	}
	public void setIsUse(String isUse) {
		this.isUse = isUse;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
