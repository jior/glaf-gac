package sysSrc.common.sysDictionary;

public class SysDictionaryDetail {
	private String check;
	private String fbigtype;
	private String fsmalltype;
	private String fconst;
	private String fislock;
	private String fremark;
	
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) { 
		this.check = check;
	}
	public String getFbigtype() {
		return fbigtype;
	}
	public void setFbigtype(String fbigtype) {
		this.fbigtype = fbigtype;
	}
	public String getFsmalltype() {
		return fsmalltype;
	}
	public void setFsmalltype(String fsmalltype) {
		this.fsmalltype = fsmalltype;
	}
	public String getFconst() {
		return fconst;
	}
	public void setFconst(String fconst) {
		this.fconst = fconst;
	}
	public String getFislock() {
		return fislock;
	}
	public void setFislock(String fislock) {
		this.fislock = fislock;
	}
	public String getFremark() {
		return fremark;
	}
	public void setFremark(String fremark) {
		this.fremark = fremark;
	}
	
	
	

}
