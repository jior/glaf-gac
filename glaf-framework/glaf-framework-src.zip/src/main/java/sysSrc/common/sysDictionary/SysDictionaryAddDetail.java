package sysSrc.common.sysDictionary;

public class SysDictionaryAddDetail {
	private String check;
	private String FBigType;
	private String FSmallType;
	private String FConst;
	private String FIsLock;
	private String FeMark;
	
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	public String getFBigType() {
		return FBigType;
	}
	public void setFBigType(String fBigType) {
		FBigType = fBigType;
	}
	public String getFSmallType() {
		return FSmallType;
	}
	public void setFSmallType(String fSmallType) {
		FSmallType = fSmallType;
	}
	public String getFConst() {
		return FConst;
	}
	public void setFConst(String fConst) {
		FConst = fConst;
	}
	public String getFIsLock() {
		return FIsLock;
	}
	public void setFIsLock(String fIsLock) {
		FIsLock = fIsLock;
	}
	public String getFeMark() {
		return FeMark;
	}
	public void setFeMark(String feMark) {
		FeMark = feMark;
	}
	

}
