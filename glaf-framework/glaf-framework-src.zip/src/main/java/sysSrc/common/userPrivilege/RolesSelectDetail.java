package sysSrc.common.userPrivilege;

public class RolesSelectDetail {
	private String p_roleName;
	private String p_roleId;
	public String getP_roleName() {
		return p_roleName;
	}
	public void setP_roleName(String name) {
		p_roleName = name;
	}
	public String getP_roleId() {
		return p_roleId;
	}
	public void setP_roleId(String id) {
		p_roleId = id;
	}
}
