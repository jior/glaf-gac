package sysSrc.common.gridTag;

import java.text.SimpleDateFormat;
import java.util.Date;

import baseSrc.common.BaseUtility;
import baseSrc.framework.BaseActionForm;

public class BPF010702Details extends BaseActionForm{
	private String no;
	private String cjbh;
	private String yfkjrny;
	private String pf;
	private String pm;
	private String bhsje;
	private String hsje;
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getCjbh() {
		return cjbh;
	}
	public void setCjbh(String cjbh) {
		this.cjbh = cjbh;
	}
	public String getYfkjrny() {
		return yfkjrny;
	}
	public void setYfkjrny(String yfkjrny) {
		this.yfkjrny = yfkjrny;
	}
	public String getPf() {
		return pf;
	}
	public void setPf(String pf) {
		this.pf = pf;
	}
	public String getPm() {
		return pm;
	}
	public void setPm(String pm) {
		this.pm = pm;
	}
	public String getBhsje() {
		return bhsje;
	}
	public void setBhsje(String bhsje) {
		this.bhsje = bhsje;
	}
	public String getHsje() {
		return hsje;
	}
	public void setHsje(String hsje) {
		this.hsje = hsje;
	}
	
	
}
