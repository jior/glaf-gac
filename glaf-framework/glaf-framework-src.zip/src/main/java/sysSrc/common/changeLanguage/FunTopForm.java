package sysSrc.common.changeLanguage;

import sysSrc.framework.SysBaseActionForm;

public class FunTopForm extends SysBaseActionForm {

	private static final long serialVersionUID = 1L;
	private String languageName;
	
	public String getLanguageName() {
		return languageName;
	}
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
    
}
