package sysSrc.common.login;

import sysSrc.framework.SysBaseActionForm;

public class LoginForm extends SysBaseActionForm {

	private static final long serialVersionUID = 1L;
	private String userId;
    private String password;
    private String password1;
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword1() {
		return password1;
	}
	public void setPassword1(String password1) {
		this.password1 = password1;
	}
    
}
