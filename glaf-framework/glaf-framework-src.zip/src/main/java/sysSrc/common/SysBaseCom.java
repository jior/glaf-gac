package sysSrc.common;

import baseSrc.common.BaseCom;


public class SysBaseCom extends BaseCom{

	private String sysTestComParm;

	public String getSysTestComParm() {
		return sysTestComParm;
	}

	public void setSysTestComParm(String sysTestComParm) {
		this.sysTestComParm = sysTestComParm;
	}
	
}
