/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.services;

import java.util.List;
import java.util.Map;

import org.jpage.core.query.paging.Page;
import org.jpage.persistence.Executor;
import org.jpage.services.dao.SqlMapDAO;

public class SqlMapManagerImpl implements SqlMapManager {

	private SqlMapDAO sqlMapDAO;

	public SqlMapManagerImpl() {

	}

	public void executeBatch(List rows) {
		if (rows != null && rows.size() > 0) {
			sqlMapDAO.executeBatch(rows);
		}
	}

	public SqlMapDAO getSqlMapDAO() {
		return sqlMapDAO;
	}

	public void setSqlMapDAO(SqlMapDAO sqlMapDAO) {
		this.sqlMapDAO = sqlMapDAO;
	}

	public void insertObject(String statementId, Object obj) {
		sqlMapDAO.insertObject(statementId, obj);
	}

	public void updateObject(String statementId, Object obj) {
		sqlMapDAO.updateObject(statementId, obj);
	}

	public void deleteObject(String statementId, Object obj) {
		sqlMapDAO.deleteObject(statementId, obj);
	}

	public void insertAll(String statementId, List rows) {
		if (rows != null && rows.size() > 0) {
			sqlMapDAO.insertAll(statementId, rows);
		}
	}

	public void updateAll(String statementId, List rows) {
		if (rows != null && rows.size() > 0) {
			sqlMapDAO.updateAll(statementId, rows);
		}
	}

	public void deleteAll(String statementId, List rows) {
		if (rows != null && rows.size() > 0) {
			sqlMapDAO.deleteAll(statementId, rows);
		}
	}

	public Object queryForObject(String statementId) {
		return sqlMapDAO.queryForObject(statementId);
	}

	public Object queryForObject(String statementId, Object parameterObject) {
		return sqlMapDAO.queryForObject(statementId, parameterObject);
	}

	public Object queryForObject(String statementId, Object parameterObject,
			Object resultObject) {
		return sqlMapDAO.queryForObject(statementId, parameterObject,
				resultObject);
	}

	public Map queryForMap(String statementId, Object parameterObject,
			String keyProperty) {
		return sqlMapDAO.queryForMap(statementId, parameterObject, keyProperty);
	}

	public Map queryForMap(String statementId, Object parameterObject,
			String keyProperty, String valueProperty) {
		return sqlMapDAO.queryForMap(statementId, parameterObject, keyProperty,
				valueProperty);
	}

	/**
	 * ��ѯ
	 * 
	 * @param executor
	 * @return
	 */
	public List query(Executor executor) {
		return sqlMapDAO.query(executor);
	}

	/**
	 * ��ȡĳҳ�ļ�¼
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param queryExecutor
	 * @return
	 */

	public List getRows(int pageNo, int pageSize, Executor queryExecutor) {
		return sqlMapDAO.getRows(pageNo, pageSize, queryExecutor);
	}

	/**
	 * ��ҳ��ѯ
	 * 
	 * @param currPageNo
	 * @param pageSize
	 * @param countExecutor
	 * @param queryExecutor
	 * @return
	 */
	public Page getPage(int currPageNo, int pageSize, Executor countExecutor,
			Executor queryExecutor) {
		return sqlMapDAO.getPage(currPageNo, pageSize, countExecutor,
				queryExecutor);
	}

}