/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.jbpm.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.jbpm.JbpmContext;
import org.jpage.core.cache.CacheFactory;
import org.jpage.core.query.paging.Page;
import org.jpage.jbpm.bytes.DataByteArray;
import org.jpage.jbpm.dao.ProcessDAO;
import org.jpage.jbpm.model.MessageInstance;
import org.jpage.jbpm.model.MessageTemplate;
import org.jpage.jbpm.persistence.PersistenceDAO;
import org.jpage.jbpm.util.MessageType;
import org.jpage.persistence.Executor;
import org.jpage.util.DateTools;
import org.jpage.util.UUID32;

public class MessageManagerImpl implements MessageManager {

 

	private ProcessDAO processDAO;

	private PersistenceDAO persistenceDAO;

	public MessageManagerImpl() {

	}

	public PersistenceDAO getPersistenceDAO() {
		return persistenceDAO;
	}

	public void setPersistenceDAO(PersistenceDAO persistenceDAO) {
		this.persistenceDAO = persistenceDAO;
	}

	public ProcessDAO getProcessDAO() {
		return processDAO;
	}

	public void setProcessDAO(ProcessDAO processDAO) {
		this.processDAO = processDAO;
	}

	/**
	 * ������Ϣģ��
	 * 
	 * @param MessageTemplate
	 */
	public void save(JbpmContext jbpmContext, MessageTemplate template) {
		if (StringUtils.isNotBlank(template.getTemplateId())) {
			template.setModifyDate(new Date());
			persistenceDAO.update(jbpmContext, template);
		} else {
			template.setCreateDate(new Date());
			template.setModifyDate(new Date());
			template.setTemplateId(UUID32.getUUID());
			persistenceDAO.save(jbpmContext, template);
		}

		if (template.getBytes() != null) {
			byte[] bytes = template.getBytes();
			DataByteArray ba = new DataByteArray(bytes);
			ba.setActorId(template.getActorId());
			ba.setCreateDate(new Date());
			ba.setName(template.getTemplateId());
			ba.setObjectId("templateId");
			ba.setObjectValue(template.getTemplateId());
			ba.setVersionNo(System.currentTimeMillis());
			persistenceDAO.save(jbpmContext, ba);
		}
	}

	/**
	 * ��ȡ��Ϣģ��
	 * 
	 * @param jbpmContext
	 * @param templateId
	 * @return
	 */
	public MessageTemplate getMessageTemplate(JbpmContext jbpmContext,
			String templateId) {
		MessageTemplate template = (MessageTemplate) persistenceDAO
				.getPersistObject(jbpmContext, MessageTemplate.class,
						templateId);
		if (template != null) {
			Executor executor = new Executor();
			executor
					.setQuery(" from org.jpage.jbpm.bytes.DataByteArray as a where a.objectValue = :objectValue order by a.versionNo desc  ");
			Map params = new HashMap();
			params.put("objectValue", templateId);
			executor.setParams(params);
			List rows = persistenceDAO.query(jbpmContext, executor);
			if (rows != null && rows.size() > 0) {
				for (int i = 0; i < rows.size(); i++) {
					DataByteArray ba = (DataByteArray) rows.get(i);
					if (ba.getByteBlocks() != null) {
						byte[] bytes = ba.getBytes();
						if (bytes != null) {
							template.setBytes(bytes);
							break;
						}
					}
				}
			}
		}
		return template;
	}

	/**
	 * ��ȡ��Ϣģ��
	 * 
	 * @param jbpmContext
	 * @param paramMap
	 * @return
	 */
	public List getMessageTemplates(JbpmContext jbpmContext, Map paramMap) {
		Map params = new HashMap();
		StringBuffer buffer = new StringBuffer();
		buffer
				.append(" from org.jpage.jbpm.model.MessageTemplate as a where 1=1 ");

		if (paramMap.get("processName") != null) {
			params.put("processName", paramMap.get("processName"));
			buffer.append(" and  a.processName = :processName ");
		}

		if (paramMap.get("taskName") != null) {
			params.put("taskName", paramMap.get("taskName"));
			buffer.append(" and  a.taskName = :taskName ");
		}

		if (paramMap.get("templateType") != null) {
			params.put("templateType", paramMap.get("templateType"));
			buffer.append(" and  a.templateType = :templateType ");
		}

		if (paramMap.get("objectId") != null) {
			params.put("objectId", paramMap.get("objectId"));
			buffer.append(" and  a.objectId = :objectId ");
		}

		if (paramMap.get("objectValue") != null) {
			params.put("objectValue", paramMap.get("objectValue"));
			buffer.append(" and  a.objectValue = :objectValue ");
		}

		buffer.append(" order by a.versionNo desc ");

		Executor executor = new Executor();
		executor.setParams(params);
		executor.setQuery(buffer.toString());

		return persistenceDAO.query(jbpmContext, executor);
	}

	/**
	 * ������Ϣ
	 * 
	 * @param processInstanceId
	 *            ����ʵ�����
	 * @param messageInstances
	 *            ��Ϣʵ��
	 * 
	 * @param messageMap
	 *            ��ϢMap�� key��value�����ַ���
	 */
	public void sendMessage(JbpmContext jbpmContext, String processInstanceId,
			Collection messageInstances) {
		if (messageInstances != null && messageInstances.size() > 0) {
			List rows = new ArrayList();
			Iterator iterator = messageInstances.iterator();
			while (iterator.hasNext()) {
				MessageInstance messageInstance = (MessageInstance) iterator
						.next();
				messageInstance.setMessageId(UUID32.getUUID());
				messageInstance.setReceiverType(0);
				messageInstance.setCreateDate(new Date());
				messageInstance.setJobDate(new Date(System.currentTimeMillis()
						+ org.jpage.util.DateTools.DAY));
				messageInstance.setDeleteFlag(0);
				messageInstance.setStatus(MessageType.NEW);
				messageInstance.setVersionNo(System.currentTimeMillis());
				rows.add(messageInstance);
			}
			processDAO.deleteMessageInstances(jbpmContext, processInstanceId);
			persistenceDAO.saveAll(jbpmContext, rows);
			CacheFactory.put(processInstanceId, new Integer(rows.size()));
		}
	}

	/**
	 * ����������ȡ��Ϣʵ��
	 * 
	 * @param jbpmContext
	 * @param params
	 * @return
	 */
	public List getMessageInstances(JbpmContext jbpmContext, Map paramMap) {
		Map params = new HashMap();
		StringBuffer buffer = new StringBuffer();
		buffer
				.append(" from org.jpage.jbpm.model.MessageInstance as a where 1=1 ");

		if (paramMap.get("messageType") != null) {
			params.put("messageType", paramMap.get("messageType"));
			buffer.append(" and  a.messageType = :messageType ");
		}

		if (paramMap.get("receiverId") != null) {
			params.put("receiverId", paramMap.get("receiverId"));
			buffer.append(" and  a.receiverId = :receiverId ");
		}

		if (paramMap.get("processInstanceId") != null) {
			params.put("processInstanceId", paramMap.get("processInstanceId"));
			buffer.append(" and  a.processInstanceId = :processInstanceId ");
		}

		if (paramMap.get("taskName") != null) {
			params.put("taskName", paramMap.get("taskName"));
			buffer.append(" and  a.taskName = :taskName ");
		}

		if (paramMap.get("objectId") != null) {
			params.put("objectId", paramMap.get("objectId"));
			buffer.append(" and  a.objectId = :objectId ");
		}

		if (paramMap.get("objectValue") != null) {
			params.put("objectValue", paramMap.get("objectValue"));
			buffer.append(" and  a.objectValue = :objectValue ");
		}

		if (paramMap.get("createDate_start") != null) {
			Object obj = paramMap.get("createDate_start");
			if (obj instanceof java.util.Date) {
				params
						.put("createDate_start", paramMap
								.get("createDate_start"));
			} else {
				String dateTime = (String) obj;
				if (!dateTime.endsWith(" 00:00:00")) {
					dateTime += " 00:00:00";
				}
				Date date = DateTools.toDate(dateTime);
				params.put("createDate_start", date);
			}
			buffer.append(" and ( a.createDate >= :createDate_start )");
		}

		if (paramMap.get("createDate_end") != null) {
			Object obj = paramMap.get("createDate_end");
			if (obj instanceof java.util.Date) {
				params.put("createDate_end", paramMap.get("createDate_end"));
			} else {
				String dateTime = (String) obj;
				if (!dateTime.endsWith(" 00:00:00")) {
					dateTime += " 00:00:00";
				}
				Date date = DateTools.toDate(dateTime);
				params.put("createDate_end", date);
			}
			buffer.append(" and ( a.createDate <= :createDate_end )");
		}

		if (paramMap.get("status") != null) {
			Object obj = paramMap.get("status");
			if (obj instanceof java.lang.Integer) {
				params.put("status", paramMap.get("status"));
			} else {
				String status = (String) obj;
				params.put("status", new Integer(status));
			}
			buffer.append(" and ( a.status = :status )");
		}

		if (paramMap.get("deleteFlag") != null) {
			Object obj = paramMap.get("deleteFlag");
			if (obj instanceof java.lang.Integer) {
				params.put("deleteFlag", paramMap.get("deleteFlag"));
			} else {
				String status = (String) obj;
				params.put("deleteFlag", new Integer(status));
			}
			buffer.append(" and ( a.deleteFlag = :deleteFlag )");
		}

		buffer.append(" order by a.versionNo desc ");

		Executor executor = new Executor();
		executor.setParams(params);
		executor.setQuery(buffer.toString());

		return persistenceDAO.query(jbpmContext, executor);
	}

	/**
	 * ��ȡһҳ��Ϣʵ������
	 * 
	 * @param currPageNo
	 * @param pageSize
	 * @param paramMap
	 * @return
	 */
	public Page getPageMessageInstances(JbpmContext jbpmContext,
			int currPageNo, int pageSize, Map paramMap) {
		Map params = new HashMap();
		StringBuffer buffer = new StringBuffer();
		buffer
				.append("  from org.jpage.jbpm.model.MessageInstance as a where 1=1 ");

		if (paramMap.get("messageType") != null) {
			params.put("messageType", paramMap.get("messageType"));
			buffer.append(" and  a.messageType = :messageType ");
		}

		if (paramMap.get("receiverId") != null) {
			params.put("receiverId", paramMap.get("receiverId"));
			buffer.append(" and  a.receiverId = :receiverId ");
		}

		if (paramMap.get("processInstanceId") != null) {
			params.put("processInstanceId", paramMap.get("processInstanceId"));
			buffer.append(" and  a.processInstanceId = :processInstanceId ");
		}

		if (paramMap.get("taskName") != null) {
			params.put("taskName", paramMap.get("taskName"));
			buffer.append(" and  a.taskName = :taskName ");
		}

		if (paramMap.get("objectId") != null) {
			params.put("objectId", paramMap.get("objectId"));
			buffer.append(" and  a.objectId = :objectId ");
		}

		if (paramMap.get("objectValue") != null) {
			params.put("objectValue", paramMap.get("objectValue"));
			buffer.append(" and  a.objectValue = :objectValue ");
		}

		if (paramMap.get("createDate_start") != null) {
			Object obj = paramMap.get("createDate_start");
			if (obj instanceof java.util.Date) {
				params
						.put("createDate_start", paramMap
								.get("createDate_start"));
			} else {
				String dateTime = (String) obj;
				if (!dateTime.endsWith(" 00:00:00")) {
					dateTime += " 00:00:00";
				}
				Date date = DateTools.toDate(dateTime);
				params.put("createDate_start", date);
			}
			buffer.append(" and ( a.createDate >= :createDate_start )");
		}

		if (paramMap.get("createDate_end") != null) {
			Object obj = paramMap.get("createDate_end");
			if (obj instanceof java.util.Date) {
				params.put("createDate_end", paramMap.get("createDate_end"));
			} else {
				String dateTime = (String) obj;
				if (!dateTime.endsWith(" 00:00:00")) {
					dateTime += " 00:00:00";
				}
				Date date = DateTools.toDate(dateTime);
				params.put("createDate_end", date);
			}
			buffer.append(" and ( a.createDate <= :createDate_end )");
		}

		if (paramMap.get("status") != null) {
			Object obj = paramMap.get("status");
			if (obj instanceof java.lang.Integer) {
				params.put("status", paramMap.get("status"));
			} else {
				String status = (String) obj;
				params.put("status", new Integer(status));
			}
			buffer.append(" and ( a.status = :status )");
		}

		if (paramMap.get("deleteFlag") != null) {
			Object obj = paramMap.get("deleteFlag");
			if (obj instanceof java.lang.Integer) {
				params.put("deleteFlag", paramMap.get("deleteFlag"));
			} else {
				String status = (String) obj;
				params.put("deleteFlag", new Integer(status));
			}
			buffer.append(" and ( a.deleteFlag = :deleteFlag )");
		}

		buffer.append(" order by a.versionNo desc ");

		Executor countExecutor = new Executor();
		Executor queryExecutor = new Executor();

		countExecutor.setQuery(" select count(distinct a.messageId) "
				+ buffer.toString());
		queryExecutor.setQuery(" select distinct a " + buffer.toString());
		countExecutor.setParams(params);
		queryExecutor.setParams(params);

		return persistenceDAO.getPage(jbpmContext, currPageNo, pageSize,
				countExecutor, queryExecutor);

	}

}
