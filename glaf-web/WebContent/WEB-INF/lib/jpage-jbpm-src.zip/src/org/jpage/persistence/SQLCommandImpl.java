/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jpage.util.JdbcUtil;

public class SQLCommandImpl implements SQLCommand {
	private final static Log logger = LogFactory.getLog(SQLCommandImpl.class);

	private Connection connection;

	private List executors;

	public SQLCommandImpl() {

	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public List getExecutors() {
		return executors;
	}

	public void setExecutors(List executors) {
		this.executors = executors;
	}

	/**
	 * ִ��SQL���
	 * 
	 */
	public void execute() {
		if (executors == null || executors.size() == 0) {
			return;
		}
		List rows = new ArrayList();
		Iterator iterator = executors.iterator();
		while (iterator.hasNext()) {
			Executor exec = (Executor) iterator.next();
			String sql = exec.getQuery();
			List fields = exec.getFields();
			Map valueMap = exec.getParams();
			if (fields != null) {
				ExecutorHelper helper = new ExecutorHelper();
				if (StringUtils.isNotBlank(exec.getGridName())) {
					Collection collection = (Collection) valueMap.get(exec
							.getGridName());
					if (collection != null && collection.size() > 0) {
						Iterator iter = collection.iterator();
						while (iter.hasNext()) {
							valueMap = (Map) iter.next();
							Executor executor = helper.getExecutor(sql, fields,
									valueMap);
							rows.add(executor);
						}
					}
				} else {
					Executor executor = helper.getExecutor(sql, fields,
							valueMap);
					rows.add(executor);
				}
			}
		}

		try {
			Iterator iterator2 = rows.iterator();
			while (iterator2.hasNext()) {
				Executor executor = (Executor) iterator2.next();
				String sql = executor.getQuery();
				Object[] values = executor.getValues();
				PreparedStatement stmt = connection.prepareStatement(sql);
				JdbcUtil.fillStatement(stmt, values);
				stmt.executeUpdate();
				stmt.close();
				stmt = null;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			logger.info("sql catch exception:" + ex);
			throw new RuntimeException(ex);
		}

	}


}
