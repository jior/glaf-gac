/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.jbpm.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.JbpmException;
import org.jbpm.context.exe.ContextInstance;
import org.jbpm.graph.def.ActionHandler;
import org.jbpm.graph.def.Node;
import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.jbpm.graph.node.TaskNode;
import org.jbpm.taskmgmt.def.Task;
import org.jbpm.taskmgmt.exe.TaskInstance;
import org.jbpm.taskmgmt.exe.TaskMgmtInstance;
import org.jpage.actor.User;
import org.jpage.jbpm.el.DefaultExpressionEvaluator;
import org.jpage.jbpm.ibatis.MutableSQLMapContainer;
import org.jpage.jbpm.util.Constant;
import org.jpage.util.Tools;

/**
 * ��̬�������ע�������Ҫ��task-node�ڵ��create-tasks�����Ըĳ�create-tasks="false" ���磺
 * <task-node name="�ɹ�����������" create-tasks="false"><br>
 * <event type="node-enter"><br>
 * <action ref-name="taskinstance_role07x"/><br>
 * </event><br>
 * <task name="task07x" description="�ɹ�����������" ></task><br>
 * <transition name="tr410" to="�ɹ�����������ͨ����"></transition><br>
 * </task-node><br>
 */
public class SqlMapTaskInstanceComplexAction implements ActionHandler {
	private static final Log logger = LogFactory
			.getLog(SqlMapTaskInstanceComplexAction.class);

	private static final long serialVersionUID = 1L;

	/**
	 * ��̬���õĲ����ߵĲ�������������������ͨ��contextInstance.getVariable()ȡ��
	 * ���磺contextInstance.getVariable("SendDocAuditor");
	 */
	protected String dynamicActors;

	/**
	 * ����
	 */
	protected String description;

	/**
	 * �������ʽ��Ϊ�գ��������������Ϊtrue��ִ��������ɡ�
	 */
	protected String expression;

	/**
	 * ���ű�Ż����ʽ
	 */
	protected String deptId;

	/**
	 * ���ż��� <br>
	 * <deptIds><br>
	 * <element>310</element><br>
	 * <element>303</element><br>
	 * </deptIds><br>
	 */
	protected List<Object> deptIds;

	/**
	 * ��ɫ��Ż����ʽ
	 */
	protected String roleId;

	/**
	 * ��ɫ���� <br>
	 * <roleIds><br>
	 * <element>R001</element><br>
	 * <element>R002</element><br>
	 * </roleIds><br>
	 */
	protected List<Object> roleIds;

	/**
	 * SqlMap��ѯ�����
	 */
	protected String queryId;

	/**
	 * �����Ż����ʽ
	 */
	protected String objectId;

	/**
	 * ����ֵ�����ʽ
	 */
	protected String objectValue;

	/**
	 * ��̬���õĲ��벿�ű�ŵĲ�������������������ͨ��contextInstance.getVariable()ȡ��
	 * ���磺contextInstance.getVariable("deptIds");
	 */
	protected String dynamicDeptIds;

	/**
	 * ת��·��������
	 */
	protected String transitionName;

	/**
	 * ��������
	 */
	protected String taskName;

	/**
	 * ������������ֻҪ��һ��ͨ���Ϳ��Եģ����ø�ֵΪtrue
	 */
	protected boolean isPooled;

	/**
	 * ���ݱ���ʽ����isPooled�Ƿ�Ϊtrue
	 */
	protected String pooledExpression;

	/**
	 * ������ܻ�ȡ����������Ƿ��뿪���ڵ㣨����ڵ㣩
	 */
	protected boolean leaveNodeIfActorNotAvailable;

	public SqlMapTaskInstanceComplexAction() {

	}

	@SuppressWarnings("unchecked")
	public void execute(ExecutionContext ctx) {
		logger.debug("-------------------------------------------------------");
		logger.debug("---------------SqlMapTaskInstanceComplexAction----------");
		logger.debug("-------------------------------------------------------");

		boolean executable = true;

		Map<String, Object> params = new HashMap<String, Object>();
		Set<String> existsActorIds = new HashSet<String>();

		ProcessInstance processInstance = ctx.getProcessInstance();
		String processInstanceId = String.valueOf(processInstance.getId());
		params.put("processInstanceId", processInstanceId);
		ContextInstance contextInstance = ctx.getContextInstance();
		Map<String, Object> variables = contextInstance.getVariables();
		if (variables != null && variables.size() > 0) {
			Set<Entry<String, Object>> entrySet = variables.entrySet();
			for (Entry<String, Object> entry : entrySet) {
				String name = entry.getKey();
				Object value = entry.getValue();
				if (name != null && value != null && params.get(name) == null) {
					params.put(name, value);
				}
			}
		}

		if (StringUtils.isNotEmpty(expression)) {
			if (expression.startsWith("#{") && expression.endsWith("}")) {
				Object value = DefaultExpressionEvaluator.evaluate(expression,
						params);
				if (value != null) {
					if (value instanceof Boolean) {
						Boolean b = (Boolean) value;
						executable = b.booleanValue();
					}
				}
			}
		}

		if (!executable) {
			logger.debug("����ʽ�����ȡֵΪfalse����ִ�к���������");
			return;
		}

		logger.debug("queryId:" + queryId);

		MutableSQLMapContainer container = MutableSQLMapContainer
				.getContainer();

		Task task = null;

		if (StringUtils.isNotEmpty(taskName)) {
			Node node = ctx.getNode();
			if (node instanceof TaskNode) {
				TaskNode taskNode = (TaskNode) node;
				task = taskNode.getTask(taskName);
			}
		}

		if (task == null) {
			task = ctx.getTask();
		}

		if (task == null) {
			throw new JbpmException(" task is null");
		}

		Token token = ctx.getToken();
		TaskMgmtInstance tmi = ctx.getTaskMgmtInstance();

		List<String> actorIds = new ArrayList<String>();

		/**
		 * �����ָ̬���������
		 */
		if (StringUtils.isNotEmpty(dynamicDeptIds)) {
			String text = (String) ctx.getVariable(dynamicDeptIds);
			List<String> dptIds = Tools.split(text);
			if (dptIds != null && !dptIds.isEmpty()) {
				params.put("roleId", roleId);
				params.put("objectId", objectId);
				params.put("objectValue", objectValue);

				if (roleIds != null && roleIds.size() > 0) {
					params.put("roleIds", roleIds);
				}

				logger.debug("�����������:" + dptIds);

				/**
				 * ���δ����������
				 */
				for (String dptId : dptIds) {
					if (StringUtils.isNotEmpty(dptId)) {
						params.put("deptId", dptId);
						logger.debug("deptId=" + deptId + ":[" + params + "]");
						Collection<Object> actors = null;
						try {
							actors = container.getList(ctx.getJbpmContext(),
									queryId, params);
							logger.debug(dptId + "����Ա:" + actors);
						} catch (Exception ex) {
							logger.error("params:" + params);
							logger.error(ex);
							ex.printStackTrace();
							throw new RuntimeException(ex);
						}

						if (actors != null && actors.size() > 0) {

							Iterator<Object> iterator = actors.iterator();
							while (iterator.hasNext()) {
								Object object = iterator.next();
								String actorId = null;
								if (object instanceof String) {
									actorId = (String) object;
								} else if (object instanceof User) {
									User user = (User) object;
									actorId = user.getActorId();
								}
								if (actorId != null) {
									actorIds.add(actorId);
								}
							}

							if (StringUtils.isNotEmpty(pooledExpression)) {
								if (pooledExpression.startsWith("#{")
										&& pooledExpression.endsWith("}")) {
									Object value = DefaultExpressionEvaluator
											.evaluate(pooledExpression, params);
									if (value != null) {
										if (value instanceof Boolean) {
											Boolean b = (Boolean) value;
											isPooled = b.booleanValue();
										}
									}
								}
							}

							logger.debug("#isPooled#:" + isPooled);

							if (isPooled) {
								if (actorIds.size() == 1) {
									String actorId = actorIds.iterator().next();
									if (!existsActorIds.contains(actorId)) {
										existsActorIds.add(actorId);
										TaskInstance taskInstance = tmi
												.createTaskInstance(task, token);
										taskInstance.setCreate(new Date());
										if (task != null) {
											taskInstance.setSignalling(task
													.isSignalling());
										}
										taskInstance.setActorId(actorId);
									}
								} else {
									int i = 0;
									Set<String> poolActorIds = new HashSet<String>();

									Iterator<String> iterator2 = actorIds
											.iterator();
									while (iterator2.hasNext()) {
										String actorId = iterator2.next();
										if (!existsActorIds.contains(actorId)) {
											poolActorIds.add(actorId);
											existsActorIds.add(actorId);
										}
									}
									if (!poolActorIds.isEmpty()) {
										String[] pooledIds = new String[poolActorIds
												.size()];
										Iterator<String> iterator4 = poolActorIds
												.iterator();
										while (iterator4.hasNext()) {
											String actorId = iterator4.next();
											pooledIds[i++] = actorId;
										}

										TaskInstance taskInstance = tmi
												.createTaskInstance(task, token);
										taskInstance.setCreate(new Date());
										if (task != null) {
											taskInstance.setSignalling(task
													.isSignalling());
										}
										taskInstance.setPooledActors(pooledIds);
									}
								}
							} else {
								Iterator<String> iterator2 = actorIds
										.iterator();
								while (iterator2.hasNext()) {
									String actorId = iterator2.next();
									if (!existsActorIds.contains(actorId)) {
										existsActorIds.add(actorId);
										TaskInstance taskInstance = tmi
												.createTaskInstance(task, token);
										taskInstance.setActorId(actorId);
										taskInstance.setCreate(new Date());
										if (task != null) {
											taskInstance.setSignalling(task
													.isSignalling());
										}
									}
								}
							}
						}
					}
				}
			}
		} else {

			if (StringUtils.isNotEmpty(dynamicActors)) {
				String actorId = (String) contextInstance
						.getVariable(dynamicActors);
				if (StringUtils.isNotEmpty(actorId)) {
					StringTokenizer st2 = new StringTokenizer(actorId, ",");
					while (st2.hasMoreTokens()) {
						String elem = st2.nextToken();
						if (StringUtils.isNotEmpty(elem)) {
							actorIds.add(elem);
						}
					}
				}
			}

			params.put("roleId", roleId);
			params.put("objectId", objectId);
			params.put("objectValue", objectValue);

			if (StringUtils.isNotEmpty(deptId)) {
				String tmp = deptId;
				Object value = deptId;
				if (tmp.startsWith("#{") && tmp.endsWith("}")) {
					value = DefaultExpressionEvaluator.evaluate(tmp, params);
				} else if (tmp.startsWith("#P{") && tmp.endsWith("}")) {
					tmp = Tools.replaceIgnoreCase(tmp, "#P{", "");
					tmp = Tools.replaceIgnoreCase(tmp, "}", "");
					value = contextInstance.getVariable(tmp);
				}
				params.put("deptId", value);
				if (value != null && value.toString().indexOf(",") != -1) {
					List<String> pieces = Tools.split(value.toString(), ",");
					params.put("deptIds", pieces);
				}
			}

			if (StringUtils.isNotEmpty(roleId)) {
				String tmp = roleId;
				Object value = roleId;
				if (tmp.startsWith("#{") && tmp.endsWith("}")) {
					value = DefaultExpressionEvaluator.evaluate(tmp, params);
				} else if (tmp.startsWith("#P{") && tmp.endsWith("}")) {
					tmp = Tools.replaceIgnoreCase(tmp, "#P{", "");
					tmp = Tools.replaceIgnoreCase(tmp, "}", "");
					value = contextInstance.getVariable(tmp);
				}
				params.put("roleId", value);
				if (value != null && value.toString().indexOf(",") != -1) {
					List<String> pieces = Tools.split(value.toString(), ",");
					params.put("roleIds", pieces);
				}
			}

			if (StringUtils.isNotEmpty(objectId)) {
				String tmp = objectId;
				Object value = objectId;
				if (tmp.startsWith("#{") && tmp.endsWith("}")) {
					value = DefaultExpressionEvaluator.evaluate(tmp, params);
				} else if (tmp.startsWith("#P{") && tmp.endsWith("}")) {
					tmp = Tools.replaceIgnoreCase(tmp, "#P{", "");
					tmp = Tools.replaceIgnoreCase(tmp, "}", "");
					value = contextInstance.getVariable(tmp);
				}
				params.put("objectId", value);
			}

			if (StringUtils.isNotEmpty(objectValue)) {
				String tmp = objectValue;
				Object value = objectValue;
				if (tmp.startsWith("#{") && tmp.endsWith("}")) {
					value = DefaultExpressionEvaluator.evaluate(tmp, params);
				} else if (tmp.startsWith("#P{") && tmp.endsWith("}")) {
					tmp = Tools.replaceIgnoreCase(tmp, "#P{", "");
					tmp = Tools.replaceIgnoreCase(tmp, "}", "");
					value = contextInstance.getVariable(tmp);
				}
				params.put("objectValue", value);
			}

			if (deptIds != null && deptIds.size() > 0) {
				params.put("deptIds", deptIds);
			}

			if (roleIds != null && roleIds.size() > 0) {
				params.put("roleIds", roleIds);
			}

			logger.debug("params:" + params);

			Collection<Object> actors = container.getList(ctx.getJbpmContext(),
					queryId, params);

			if (actors != null && actors.size() > 0) {
				Iterator<Object> iterator = actors.iterator();
				while (iterator.hasNext()) {
					Object object = iterator.next();
					String actorId = null;
					if (object instanceof String) {
						actorId = (String) object;
					} else if (object instanceof User) {
						User user = (User) object;
						actorId = user.getActorId();
					}
					if (actorId != null) {
						actorIds.add(actorId);
					}
				}
			}

			logger.debug("actorIds:" + actorIds);

			if (actorIds.size() > 0) {

				if (StringUtils.isNotEmpty(pooledExpression)) {
					if (pooledExpression.startsWith("#{")
							&& pooledExpression.endsWith("}")) {
						Object value = DefaultExpressionEvaluator.evaluate(
								pooledExpression, params);
						if (value != null) {
							if (value instanceof Boolean) {
								Boolean b = (Boolean) value;
								isPooled = b.booleanValue();
							}
						}
					}
				}
				
				logger.debug("#isPooled#:" + isPooled);

				if (isPooled) {

					if (actorIds.size() == 1) {
						String actorId = actorIds.iterator().next();
						if (!existsActorIds.contains(actorId)) {
							existsActorIds.add(actorId);
							TaskInstance taskInstance = tmi.createTaskInstance(
									task, token);
							taskInstance.setCreate(new Date());
							if (task != null) {
								taskInstance.setSignalling(task.isSignalling());
							}
							taskInstance.setActorId(actorId);
						}
					} else {
						int i = 0;
						Set<String> poolActorIds = new HashSet<String>();

						Iterator<String> iterator2 = actorIds.iterator();
						while (iterator2.hasNext()) {
							String actorId = iterator2.next();
							if (!existsActorIds.contains(actorId)) {
								poolActorIds.add(actorId);
								existsActorIds.add(actorId);
							}
						}
						if (!poolActorIds.isEmpty()) {
							String[] pooledIds = new String[poolActorIds.size()];
							Iterator<String> iterator4 = poolActorIds
									.iterator();
							while (iterator4.hasNext()) {
								String actorId = iterator4.next();
								pooledIds[i++] = actorId;
							}

							TaskInstance taskInstance = tmi.createTaskInstance(
									task, token);
							taskInstance.setCreate(new Date());
							if (task != null) {
								taskInstance.setSignalling(task.isSignalling());
							}
							taskInstance.setPooledActors(pooledIds);
						}
					}
				} else {
					Iterator<String> iterator = actorIds.iterator();
					while (iterator.hasNext()) {
						String actorId = iterator.next();
						if (!existsActorIds.contains(actorId)) {
							existsActorIds.add(actorId);
							TaskInstance taskInstance = tmi.createTaskInstance(
									task, token);
							taskInstance.setActorId(actorId);
							taskInstance.setCreate(new Date());
							if (task != null) {
								taskInstance.setSignalling(task.isSignalling());
							}
						}
					}
				}
			} else {
				if (leaveNodeIfActorNotAvailable) {
					contextInstance.setVariable(Constant.IS_AGREE, "true");
					if (StringUtils.isNotEmpty(transitionName)) {
						ctx.leaveNode(transitionName);
					} else {
						ctx.leaveNode();
					}
					return;
				}
			}
		}
	}

	public String getDeptId() {
		return deptId;
	}

	public List<Object> getDeptIds() {
		return deptIds;
	}

	public String getDescription() {
		return description;
	}

	public String getDynamicActors() {
		return dynamicActors;
	}

	public String getExpression() {
		return expression;
	}

	public String getObjectId() {
		return objectId;
	}

	public String getObjectValue() {
		return objectValue;
	}

	public String getPooledExpression() {
		return pooledExpression;
	}

	public String getQueryId() {
		return queryId;
	}

	public String getRoleId() {
		return roleId;
	}

	public List<Object> getRoleIds() {
		return roleIds;
	}

	public String getTaskName() {
		return taskName;
	}

	public String getTransitionName() {
		return transitionName;
	}

	public boolean isLeaveNodeIfActorNotAvailable() {
		return leaveNodeIfActorNotAvailable;
	}

	public boolean isPooled() {
		return isPooled;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public void setDeptIds(List<Object> deptIds) {
		this.deptIds = deptIds;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setDynamicActors(String dynamicActors) {
		this.dynamicActors = dynamicActors;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public void setLeaveNodeIfActorNotAvailable(
			boolean leaveNodeIfActorNotAvailable) {
		this.leaveNodeIfActorNotAvailable = leaveNodeIfActorNotAvailable;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public void setObjectValue(String objectValue) {
		this.objectValue = objectValue;
	}

	public void setPooled(boolean isPooled) {
		this.isPooled = isPooled;
	}

	public void setPooledExpression(String pooledExpression) {
		this.pooledExpression = pooledExpression;
	}

	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public void setRoleIds(List<Object> roleIds) {
		this.roleIds = roleIds;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public void setTransitionName(String transitionName) {
		this.transitionName = transitionName;
	}

}
