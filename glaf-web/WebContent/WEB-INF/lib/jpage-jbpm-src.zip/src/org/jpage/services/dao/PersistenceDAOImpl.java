/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.services.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.jpage.core.query.paging.Page;
import org.jpage.persistence.Executor;
import org.jpage.persistence.PersistenceType;
import org.jpage.util.HibernateUtil;
import org.jpage.util.JdbcUtil;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * ���ݿ�־ò���ʽӿ� ��Ҫ��ͨ��Spring��Hibernateģ����ɳ��õ����ݿ����
 * 
 */
public class PersistenceDAOImpl extends HibernateDaoSupport implements
		PersistenceDAO {

	private final static Log logger = LogFactory
			.getLog(PersistenceDAOImpl.class);

	/**
	 * �洢���л�����
	 * 
	 * @param obj
	 */
	public void save(final Object obj) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				session.save(obj);
				return null;
			}
		});
	}

	/**
	 * �洢���л�����
	 * 
	 * @param rows
	 */
	public void saveAll(final Collection rows) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				if (rows != null && rows.size() > 0) {
					Iterator iterator = rows.iterator();
					while (iterator.hasNext()) {
						Object obj = iterator.next();
						session.save(obj);
					}
				}
				return null;
			}
		});
	}

	/**
	 * �޸����л�����
	 * 
	 * @param obj
	 */
	public void update(final Object obj) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				session.update(obj);
				return null;
			}
		});
	}

	/**
	 * �޸����л�����
	 * 
	 * @param rows
	 */
	public void updateAll(final Collection rows) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				if (rows != null && rows.size() > 0) {
					Iterator iterator = rows.iterator();
					while (iterator.hasNext()) {
						Object obj = iterator.next();
						session.update(obj);
					}
				}
				return null;
			}
		});
	}

	/**
	 * ������޸Ķ���
	 * 
	 * @param obj
	 */
	public void saveOrUpdate(final Object obj) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				if (obj != null && obj instanceof Collection) {
					Collection rows = (Collection) obj;
					Iterator iterator = rows.iterator();
					while (iterator.hasNext()) {
						Object obj = iterator.next();
						session.saveOrUpdate(obj);
					}
				} else {
					session.saveOrUpdate(obj);
				}
				return null;
			}
		});
	}

	/**
	 * �־û�����
	 * 
	 * @param obj
	 */
	public void persist(final Object obj) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				if (obj != null && obj instanceof Collection) {
					Collection rows = (Collection) obj;
					Iterator iterator = rows.iterator();
					while (iterator.hasNext()) {
						Object obj = iterator.next();
						session.persist(obj);
					}
				} else {
					session.persist(obj);
				}
				return null;
			}
		});
	}

	/**
	 * ɾ�����л�����
	 * 
	 * @param obj
	 */
	public void delete(final Object obj) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				if (obj != null && obj instanceof Collection) {
					Collection rows = (Collection) obj;
					Iterator iterator = rows.iterator();
					while (iterator.hasNext()) {
						Object obj = iterator.next();
						session.delete(obj);
					}
				} else {
					session.delete(obj);
				}
				return null;
			}
		});
	}

	/**
	 * ɾ�����л�����
	 * 
	 * @param obj
	 */
	public void deleteAll(final Collection rows) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				if (rows != null && rows.size() > 0) {
					Iterator iterator = rows.iterator();
					while (iterator.hasNext()) {
						Object obj = iterator.next();
						session.delete(obj);
					}
				}
				return null;
			}
		});
	}

	/**
	 * ����ָ����SQLɾ������<br>
	 * ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
	 * 
	 * @param sql
	 * @param value
	 * @param type
	 */
	public void delete(final String sql, final Object value) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(sql);
				if (value != null) {
					query.setParameter(0, value);
				}
				if (sql.trim().toLowerCase().startsWith("delete")) {
					int result = query.executeUpdate();
					logger.debug("delete rows : " + result);
				} else {
					List rows = query.list();
					if (rows != null && rows.size() > 0) {
						Iterator iterator = rows.iterator();
						while (iterator.hasNext()) {
							Object obj = iterator.next();
							session.delete(obj);
						}
					}
				}
				return null;
			}
		});
	}

	/**
	 * ����ָ����SQLɾ������<br>
	 * ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
	 * 
	 * @param sql
	 * @param values
	 */
	public void delete(final String sql, final Object[] values) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(sql);
				if (values != null) {
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}
				}
				if (sql.trim().toLowerCase().startsWith("delete")) {
					int result = query.executeUpdate();
					logger.debug("delete rows : " + result);
				} else {
					List rows = query.list();
					if (rows != null && rows.size() > 0) {
						Iterator iterator = rows.iterator();
						while (iterator.hasNext()) {
							Object obj = iterator.next();
							session.delete(obj);
						}
					}
				}
				return null;
			}
		});
	}

	/**
	 * ����������ȡ�־û�����
	 * 
	 * @param clazz
	 *            ����
	 * @param persistId
	 *            ����ֵ
	 * @return
	 */
	public Object getPersistObject(final Class clazz,
			final java.io.Serializable persistId) {
		return getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(Session session)
					throws HibernateException {
				Object obj = session.get(clazz, persistId);
				return obj;
			}
		});
	}

	/**
	 * ��ȡĳ������ĳ���ֶε����ֵ
	 * 
	 * @param tablename
	 * @param fieldname
	 * @return
	 */
	public long getMaxId(final String tablename, final String fieldname) {
		Long obj = (Long) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(org.hibernate.Session session)
							throws org.hibernate.HibernateException,
							SQLException {
						String sql = " select max(" + fieldname + ") from "
								+ tablename;
						long l = 0L;
						Connection con = HibernateUtil.getConnection(session);
						Statement stmt = con.createStatement();
						ResultSet rs = stmt.executeQuery(sql);
						if (rs.next()) {
							l = rs.getLong(1);
						}
						rs.close();
						stmt.close();
						return new Long(l);
					}
				});
		return obj.longValue();
	}

	/**
	 * ִ��SQL���
	 * 
	 * @param sql
	 */
	public void executeSQL(final String sql) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException, SQLException {
				Connection con = HibernateUtil.getConnection(session);
				Statement stmt = con.createStatement();
				stmt.executeUpdate(sql);
				return null;
			}
		});
	}

	/**
	 * ִ��SQL���
	 * 
	 * @param sql
	 * @param params
	 */
	public void executeSQL(final String sql, final Object[] params) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException, SQLException {
				Connection con = HibernateUtil.getConnection(session);
				PreparedStatement psmt = con.prepareStatement(sql);
				JdbcUtil.fillStatement(psmt, params);
				psmt.executeUpdate();
				return null;
			}
		});
	}

	/**
	 * ����ִ��HibernateSQL ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
	 * 
	 * @param params
	 */
	public void execute(final List params) {
		getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Iterator iterator = params.iterator();
				while (iterator.hasNext()) {
					Executor executor = (Executor) iterator.next();
					Object[] values = executor.getValues();
					// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
					int persistenceType = executor.getPersistenceType();
					switch (persistenceType) {
					case PersistenceType.SAVE_TYPE:
						if (values != null) {
							for (int i = 0; i < values.length; i++) {
								Object obj = values[i];
								session.save(obj);
							}
						}
						break;
					case PersistenceType.UPDATE_TYPE:
						if (values != null) {
							for (int i = 0; i < values.length; i++) {
								Object obj = values[i];
								session.update(obj);
							}
						}
						break;
					case PersistenceType.DELETE_TYPE:
						if (executor.getQuery() != null) {
							Query q = session.createQuery(executor.getQuery());
							if (values != null) {
								for (int i = 0; i < values.length; i++) {
									q.setParameter(i, values[i]);
								}
							}
							if (executor.getQuery().trim().toLowerCase()
									.startsWith("delete")) {
								int result = q.executeUpdate();
								logger.debug("delete rows : " + result);
							} else {
								List rows = q.list();
								if (rows != null && rows.size() > 0) {
									Iterator iter = rows.iterator();
									while (iter.hasNext()) {
										Object obj = iter.next();
										session.delete(obj);
									}
								}
							}
						}
						break;
					}
				}
				return null;
			}
		});
	}

	/**
	 * �ں϶���
	 * 
	 * @param obj
	 * @return
	 */
	public Object merge(final Object obj) {
		return getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				return session.merge(obj);
			}
		});
	}

	/**
	 * ��ѯ
	 * 
	 * @param sql
	 * @return
	 */
	public List query(final String sql) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(sql);
				List rows = query.list();
				return rows;
			}
		});
	}

	/**
	 * ��ѯ<br>
	 * ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
	 * 
	 * @param sql
	 * @param value
	 * @return
	 */
	public List query(final String sql, final Object value) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(sql);
				if (value != null) {
					query.setParameter(0, value);
				}
				List rows = query.list();
				return rows;
			}
		});
	}

	/**
	 * ��ѯ<br>
	 * ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
	 * 
	 * @param sql
	 * @param values
	 * @return
	 */
	public List query(final String sql, final Object[] values) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(sql);
				if (values != null) {
					// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}
				}
				List rows = query.list();
				return rows;
			}
		});
	}

	/**
	 * ��ѯ
	 * 
	 * @param executor
	 * @return
	 */
	public List query(final Executor executor) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(executor.getQuery());

				Object[] values = executor.getValues();
				if (values != null) {

					// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}
				}

				Map params = executor.getParams();

				if (params != null && params.size() > 0) {
					Iterator iterator = params.keySet().iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
						Object value = params.get(name);
						if (value != null) {
							if (value instanceof Collection) {
								query
										.setParameterList(name,
												(Collection) value);
							} else {
								query.setParameter(name, value);
							}
						}
					}
				}

				if (executor.isCacheable()) {
					query.setCacheable(true);
				}
				List rows = query.list();
				return rows;
			}
		});
	}

	/**
	 * ����SQL��ѯ
	 * 
	 * @param executor
	 * @return
	 */
	public List queryByNativeSQL(final Executor executor) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createSQLQuery(executor.getQuery());

				Object[] values = executor.getValues();
				if (values != null) {
					// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}
				}

				Map params = executor.getParams();

				if (params != null && params.size() > 0) {
					Iterator iterator = params.keySet().iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
						Object value = params.get(name);
						if (value != null) {
							if (value instanceof Collection) {
								query
										.setParameterList(name,
												(Collection) value);
							} else {
								query.setParameter(name, value);
							}
						}
					}
				}

				List rows = query.list();
				return rows;
			}
		});
	}

	/**
	 * ��ѯ
	 * 
	 * @param sql
	 * @param name
	 * @param values
	 * @return
	 */
	public List query(final String sql, final String name,
			final Collection values) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(sql);
				query.setParameterList(name, values);
				List rows = query.list();
				return rows;
			}
		});
	}

	/**
	 * ������ѯ
	 * 
	 * @param detachedCriteria
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List getRowsByCriteria(final DetachedCriteria detachedCriteria,
			final int pageNo, final int pageSize) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Criteria criteria = detachedCriteria
						.getExecutableCriteria(session);
				criteria.setProjection(null);
				List rows = criteria.setFirstResult((pageNo - 1) * pageSize)
						.setMaxResults(pageSize).list();
				return rows;
			}
		});
	}

	/**
	 * ��ȡ��¼����
	 * 
	 * @param detachedCriteria
	 * @return
	 */
	public int getCountByCriteria(final DetachedCriteria detachedCriteria) {
		Integer count = (Integer) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session)
							throws HibernateException {
						Criteria criteria = detachedCriteria
								.getExecutableCriteria(session);
						return criteria.setProjection(Projections.rowCount())
								.uniqueResult();
					}
				});
		return count.intValue();
	}

	/**
	 * ��ȡĳҳ�ļ�¼
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param queryExecutor
	 * @return
	 */

	public List getRows(final int pageNo, final int pageSize,
			final Executor queryExecutor) {
		return (List) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Query query = session.createQuery(queryExecutor.getQuery());
				Object[] values = queryExecutor.getValues();

				if (values != null && values.length > 0) {
					// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}
				}

				Map params = queryExecutor.getParams();

				if (params != null && params.size() > 0) {
					Iterator iterator = params.keySet().iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
						Object value = params.get(name);
						if (value != null) {
							if (value instanceof Collection) {
								query
										.setParameterList(name,
												(Collection) value);
							} else {
								query.setParameter(name, value);
							}
						}
					}
				}

				if (queryExecutor.isCacheable()) {
					query.setCacheable(true);
				}
				query.setFirstResult((pageNo - 1) * pageSize);
				query.setMaxResults(pageSize);
				List rows = query.list();

				if (logger.isDebugEnabled()) {
					logger.debug("query :" + query.getQueryString());
					if (params != null) {
						logger.debug("params:" + params);
					}
					if (values != null) {
						logger.debug("values:" + Arrays.asList(values));
					}
					logger.debug("rows size:" + rows.size());
				}

				return rows;
			}
		});
	}

	/**
	 * ��ҳ��ѯ
	 * 
	 * @param currPageNo
	 * @param pageSize
	 * @param countExecutor
	 * @param queryExecutor
	 * @return
	 */
	public Page getPage(final int pageNo, final int pSize,
			final Executor countExecutor, final Executor queryExecutor) {
		return (Page) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Page page = new Page();
				int currPageNo = pageNo;
				int pageSize = pSize;
				if (pageSize <= 0) {
					pageSize = Page.DEFAULT_PAGE_SIZE;
				}
				if (currPageNo <= 0) {
					currPageNo = 1;
				}
				int totalCount = 0;
				if (countExecutor != null) {
					Object obj = null;
					Query q = session.createQuery(countExecutor.getQuery());
					Object[] values = countExecutor.getValues();
					if (values != null && values.length > 0) {
						// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
						for (int i = 0; i < values.length; i++) {
							q.setParameter(i, values[i]);
						}
					}

					Map params = countExecutor.getParams();

					if (params != null && params.size() > 0) {
						Iterator iterator = params.keySet().iterator();
						while (iterator.hasNext()) {
							String name = (String) iterator.next();
							Object value = params.get(name);
							if (value != null) {
								if (value instanceof Collection) {
									q
											.setParameterList(name,
													(Collection) value);
								} else {
									q.setParameter(name, value);
								}
							}
						}
					}

					obj = q.iterate().next();

					if (obj instanceof Integer) {
						Integer iCount = (Integer) obj;
						totalCount = iCount.intValue();
					} else if (obj instanceof Long) {
						Long iCount = (Long) obj;
						totalCount = iCount.intValue();
					} else if (obj instanceof BigDecimal) {
						BigDecimal bg = (BigDecimal) obj;
						totalCount = bg.intValue();
					} else if (obj instanceof BigInteger) {
						BigInteger bi = (BigInteger) obj;
						totalCount = bi.intValue();
					}

				} else {
					List list = null;
					Query q = session.createQuery(queryExecutor.getQuery());
					Object[] values = queryExecutor.getValues();
					if (values != null && values.length > 0) {
						for (int i = 0; i < values.length; i++) {
							q.setParameter(i, values[i]);
						}
					}

					Map params = queryExecutor.getParams();

					if (params != null && params.size() > 0) {
						Iterator iterator = params.keySet().iterator();
						while (iterator.hasNext()) {
							String name = (String) iterator.next();
							Object value = params.get(name);
							if (value != null) {
								if (value instanceof Collection) {
									q
											.setParameterList(name,
													(Collection) value);
								} else {
									q.setParameter(name, value);
								}
							}
						}
					}

					list = q.list();

					if (list != null) {
						totalCount = list.size();
					}
				}

				if (totalCount == 0) {
					page.setRows(new ArrayList());
					page.setCurrentPage(0);
					page.setPageSize(0);
					page.setTotalRecordCount(0);
					return page;
				}

				page.setTotalRecordCount(totalCount);

				int maxPageNo = (page.getTotalRecordCount() + (pageSize - 1))
						/ pageSize;
				if (currPageNo > maxPageNo) {
					currPageNo = maxPageNo;
				}

				Query query = session.createQuery(queryExecutor.getQuery());
				Object[] values = queryExecutor.getValues();

				if (values != null && values.length > 0) {
					// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}

					if (queryExecutor.isCacheable()) {
						query.setCacheable(true);
					}
				}

				Map params = queryExecutor.getParams();

				if (params != null && params.size() > 0) {
					Iterator iterator = params.keySet().iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
						Object value = params.get(name);
						if (value != null) {
							if (value instanceof Collection) {
								query
										.setParameterList(name,
												(Collection) value);
							} else {
								query.setParameter(name, value);
							}
						}
					}
					if (queryExecutor.isCacheable()) {
						query.setCacheable(true);
					}
				}

				if (totalCount < pageSize) {
					pageSize = totalCount;
				}

				query.setFirstResult((currPageNo - 1) * pageSize);
				query.setMaxResults(pageSize);

				List rows = query.list();
				page.setRows(rows);
				page.setPageSize(pageSize);
				page.setCurrentPage(currPageNo);

				if (logger.isDebugEnabled()) {
					logger.debug("query :" + query.getQueryString());
					if (params != null) {
						logger.debug("params:" + params);
					}
					if (values != null) {
						logger.debug("values:" + Arrays.asList(values));
					}
					logger.debug("rows size:" + rows.size());
				}

				return page;
			}
		});
	}

	/**
	 * ��ҳ��ѯ
	 * 
	 * @param currPageNo
	 * @param pageSize
	 * @param countExecutor
	 * @param queryExecutor
	 * @return
	 */
	public Page getSQLQueryPage(final int pageNo, final int pSize,
			final Executor countExecutor, final Executor queryExecutor) {
		return (Page) getHibernateTemplate().execute(new HibernateCallback() {
			public Object doInHibernate(org.hibernate.Session session)
					throws org.hibernate.HibernateException {
				Page page = new Page();
				int currPageNo = pageNo;
				int pageSize = pSize;
				if (pageSize <= 0) {
					pageSize = Page.DEFAULT_PAGE_SIZE;
				}
				if (currPageNo <= 0) {
					currPageNo = 1;
				}
				int totalCount = 0;
				if (countExecutor != null) {
					Object obj = null;
					Query q = session.createSQLQuery(countExecutor.getQuery());
					Object[] values = countExecutor.getValues();
					if (values != null && values.length > 0) {
						// ����Ĳ���ռλ���Ǳ�׼��jdbcռλ����?��������Hibernate��(:parameter)��
						for (int i = 0; i < values.length; i++) {
							q.setParameter(i, values[i]);
						}
					}

					Map params = countExecutor.getParams();
					if (params != null && params.size() > 0) {
						Iterator iterator = params.keySet().iterator();
						while (iterator.hasNext()) {
							String name = (String) iterator.next();
							Object value = params.get(name);
							if (value != null) {
								if (value instanceof Collection) {
									q
											.setParameterList(name,
													(Collection) value);
								} else {
									q.setParameter(name, value);
								}
							}
						}
					}

					obj = q.iterate().next();

					if (logger.isDebugEnabled()) {
						logger.debug(obj.getClass().getName());
					}

					if (obj instanceof Integer) {
						Integer iCount = (Integer) obj;
						totalCount = iCount.intValue();
					} else if (obj instanceof Long) {
						Long iCount = (Long) obj;
						totalCount = iCount.intValue();
					} else if (obj instanceof BigDecimal) {
						BigDecimal bg = (BigDecimal) obj;
						totalCount = bg.intValue();
					} else if (obj instanceof BigInteger) {
						BigInteger bi = (BigInteger) obj;
						totalCount = bi.intValue();
					}

				} else {
					List list = null;
					Query q = session.createSQLQuery(queryExecutor.getQuery());
					Object[] values = queryExecutor.getValues();
					if (values != null && values.length > 0) {
						for (int i = 0; i < values.length; i++) {
							q.setParameter(i, values[i]);
						}
					}

					Map params = queryExecutor.getParams();
					if (params != null && params.size() > 0) {
						Iterator iterator = params.keySet().iterator();
						while (iterator.hasNext()) {
							String name = (String) iterator.next();
							Object value = params.get(name);
							if (value != null) {
								if (value instanceof Collection) {
									q
											.setParameterList(name,
													(Collection) value);
								} else {
									q.setParameter(name, value);
								}
							}
						}
					}

					list = q.list();

					if (list != null) {
						totalCount = list.size();
					}
				}

				if (totalCount == 0) {
					page.setRows(new ArrayList());
					page.setCurrentPage(0);
					page.setPageSize(0);
					page.setTotalRecordCount(0);
					return page;
				}

				page.setTotalRecordCount(totalCount);

				int maxPageNo = (page.getTotalRecordCount() + (pageSize - 1))
						/ pageSize;
				if (currPageNo > maxPageNo) {
					currPageNo = maxPageNo;
				}

				SQLQuery query = session.createSQLQuery(queryExecutor
						.getQuery());
				Object[] values = queryExecutor.getValues();

				if (values != null && values.length > 0) {
					for (int i = 0; i < values.length; i++) {
						query.setParameter(i, values[i]);
					}
				}

				Map params = queryExecutor.getParams();
				if (params != null && params.size() > 0) {
					Iterator iterator = params.keySet().iterator();
					while (iterator.hasNext()) {
						String name = (String) iterator.next();
						Object value = params.get(name);
						if (value != null) {
							if (value instanceof Collection) {
								query
										.setParameterList(name,
												(Collection) value);
							} else {
								query.setParameter(name, value);
							}
						}
					}
				}

				query.setFirstResult((currPageNo - 1) * pageSize);
				query.setMaxResults(pageSize);

				List rows = query.list();
				page.setRows(rows);
				page.setPageSize(pageSize);
				page.setCurrentPage(currPageNo);

				if (logger.isDebugEnabled()) {
					logger.debug("query :" + query.getQueryString());
					if (params != null) {
						logger.debug("params:" + params);
					}
					if (values != null) {
						logger.debug("values:" + Arrays.asList(values));
					}
					logger.debug("rows size:" + rows.size());
				}

				return page;
			}
		});
	}

}