/*
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package org.jpage.datacenter.variable;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public class ByteArray implements Serializable {

	private static final long serialVersionUID = 1L;

	protected long id = 0;

	protected String name = null;

	protected long categoryId = 0;

	protected String resourceId = null;

	protected String objectId = null;

	protected String objectValue = null;

	protected long versionNo = 0;

	protected List byteBlocks = null;

	public ByteArray() {
	}

	public byte[] getBytes() {
		return ByteBlockChopper.glueChopsBackTogether(byteBlocks);
	}

	public void setBytes(byte[] bytes) {
		this.byteBlocks = ByteBlockChopper.chopItUp(bytes);
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getObjectValue() {
		return objectValue;
	}

	public void setObjectValue(String objectValue) {
		this.objectValue = objectValue;
	}

	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public long getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(long versionNo) {
		this.versionNo = versionNo;
	}

	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		if (!(o instanceof ByteArray)) {
			return false;
		}
		ByteArray other = (ByteArray) o;
		return Arrays.equals(
				ByteBlockChopper.glueChopsBackTogether(byteBlocks),
				ByteBlockChopper.glueChopsBackTogether(other.byteBlocks));
	}

	public int hashCode() {
		if (byteBlocks == null)
			return 0;
		return byteBlocks.hashCode();
	}

	public List getByteBlocks() {
		return byteBlocks;
	}
}
